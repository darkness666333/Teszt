/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package szakdolgozat;

/**
 *
 * @author Merci
 */
public class AlapClass {
    private String Nev;
    private String FelhaszNev;
    private String jelszo;
    

    public String getNev(){
        return Nev;
    }
    
    public String getFelhaszNev(){
        return FelhaszNev;
    }

    public String getJelszo() {
        return jelszo;
    }
    
}
